export default function Chickens() {
  return (
    <div>
      <h1>Vlado Tomovic</h1>
    </div>
  );
}
