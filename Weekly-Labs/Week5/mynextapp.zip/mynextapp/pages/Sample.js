import React from 'react';

export default function Sample() {
  return <div>Sample</div>;
}
